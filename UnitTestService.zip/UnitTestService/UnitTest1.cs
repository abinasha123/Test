﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Repository;
using Repository.RepoModel;
using System;

namespace UnitTestService
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            //Guid id = new Guid("11223344-5566-7788-99AA-BBCCDDEEFF00");
            //ServiceRequest sr = new ServiceRequest();
            //ServiceTable st= sr.GetServiceRequest(id);
            Assert.AreEqual(5,5);   
        }
    }
}
