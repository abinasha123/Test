﻿using Repository.RepoModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ServiceRequest : IServiceRequest
    {
        public void DeleteServiceRequest(Guid id)
        {
            try { 
            using (ServiceDBEntities1 ServiceDBE = new ServiceDBEntities1())
            {
                var ServiceDetails = ServiceDBE.ServiceTables.FirstOrDefault(x => x.Serviceid == id);
                if (ServiceDetails != null)
                {
                    ServiceDBE.ServiceTables.Remove(ServiceDetails);
                    ServiceDBE.SaveChanges();
                }
            }
        }
            catch(Exception ex)
            {

            }
}

        public ServiceTable GetServiceRequest(Guid id)
        {
            try
            {

            
            using (ServiceDBEntities1 ServiceDBE = new ServiceDBEntities1())
            {
                var servicetable = (from p in ServiceDBE.ServiceTables
                                    select new
                                    {
                                        serviceid = p.Serviceid,
                                        Buildingcode = p.buildingCode,
                                        Description = p.description,
                                        CurrentStatus = p.CurrentStatus,
                                        CreatedBy = p.createdBy,
                                        CreatedDate = p.createdDate,
                                        LastModifiedBy = p.lastModifiedBy,
                                        LastModifiedDate = p.lastModifiedDate
                                    }).ToList()
             .Select(x => new ServiceTable()
             {
                 Serviceid = x.serviceid,
                 buildingCode = x.Buildingcode,
                 description = x.Description,
                 CurrentStatus = x.CurrentStatus,
                 createdBy = x.CreatedBy,
                 createdDate = x.CreatedDate,
                 lastModifiedBy = x.LastModifiedBy,
                 lastModifiedDate = x.LastModifiedDate
             });
                return servicetable.FirstOrDefault(x => x.Serviceid == id);
            }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public void PostServiceRequest(ServiceTable tableData)
        {
            try { 
            using (ServiceDBEntities1 ServiceDBE = new ServiceDBEntities1())
            {
                ServiceTable ST = new ServiceTable()
                {

                    Serviceid = Guid.NewGuid(),
                    buildingCode = tableData.buildingCode,// "101",
                    description = tableData.description,// "Service Request",
                    CurrentStatus = tableData.CurrentStatus,// "Progress",
                    createdBy = tableData.createdBy,// "abinash",
                    createdDate = tableData.createdDate,// DateTime.Now,
                    lastModifiedBy = tableData.lastModifiedBy,//"Hota sir",
                    lastModifiedDate = tableData.lastModifiedDate//  DateTime.Now
                };
                ServiceDBE.ServiceTables.Add(ST);
                ServiceDBE.SaveChanges();
            }
            }
            catch (Exception ex)
            {

            }
        }

        public void UpdateServiceReuest(ServiceTable ST, Guid id)
        {
            try
            { 
            using (ServiceDBEntities1 ServiceDBE = new ServiceDBEntities1())
            {
                var ServiceDetails = ServiceDBE.ServiceTables.FirstOrDefault(x => x.Serviceid == id);
                if (ServiceDetails != null)
                {
                    ServiceDetails.buildingCode = ST.buildingCode;
                    ServiceDetails.description = ST.description;
                    ServiceDetails.CurrentStatus = ST.CurrentStatus;
                    ServiceDetails.createdBy = ST.createdBy;
                    //  ServiceDetails.createdDate =ST.createdDate;
                    ServiceDetails.lastModifiedBy = ST.lastModifiedBy;
                    ServiceDetails.lastModifiedDate = ST.lastModifiedDate;
                    ServiceDBE.SaveChanges();
                    if (ST.CurrentStatus == "Complete")
                    {
                        SendMail();
                    }

                }
            }
            }
            catch(Exception ex)
            {

            }
        }

        private void SendMail()
        {
            //Send mail to the Client who raised request
        }
    }
}
